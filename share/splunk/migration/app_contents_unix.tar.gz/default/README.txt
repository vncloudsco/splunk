Splunk for UNIX

Copyright (c) 2010 by Splunk, Inc.

The Splunk for UNIX application supports a variety of different log records or data sources. Among them:

   * Generic UNIX syslog events
   * UNIX services, such as ssh, ftp, dhcp, cron, snmpd, named, and so on 
   * UNIX system monitoring (ps, top, vmstat, etc.)
   * Linux iptables firewall
   * OS X ipfw firewall
   * OpenBSD PF firewall

The supported scripted inputs are:

   * audit
   * df
   * iostat
   * lsof
   * netsat
   * ps
   * time/date
   * top
   * vmstat
   * package management (yum, dpkg)

++ Installation and configuration

This application is compatible with Splunk 4.0 and higher.

See [howto:Install_Splunk_Compliant_Data_Source_Add-ons the installation how-to] for generic instructions of how to install and configure this add-on.

+++ Scripted input configuration

To enable the scripted inputs to monitor ps, vmstat, iostat, and so on, do the following:

1) Modify any of the stanza's to tailor their enabled/disabled, interval ( sec ), source, sourcetype. 
2) If you have installed in non-default places you may need to fix the paths in some of the bin scripts
3) By default all monitoring data is placed into the default index
4) The iostat input requires iostat installed. It's in the sysstat RPM which can often be installed with "yum install sysstat"
5) Enable the inputs you want in inputs.conf with "disabled = false"
6) Don't forget to restart splunk.  Once running, check splunkd.log for errors.

+++ auditd

auditd is available on Linux.  Here's how to set it up on the system:

Reference: http://www.cyberciti.biz/tips/linux-audit-files-to-see-who-made-changes-to-a-file.html

1) Install if needed, but it should be there
> yum install audit

2) Make sure it starts on boot
> chkconfig audit on

3) Start if necessary
> /etc/init.d/auditd start

4) Add a file to be watched
> auditctl -w /etc/passwd -p wa -k splunk
-w is file, -p is actions (write, append, read, execute), -k is an optional key tag added to the audit.log entry.
5) Make a change to the file
> useradd mrevil

6) see the change
> ausearch -i -f /etc/passwd
-i means translate so you see user's name instead of uid.  -f is file to look for.  Ausearch has lots of args for searching

++ Operating system support

This application supports most UNIX flavors, such as FreeBSD, Solaris, AIX, Linux, and OSX
