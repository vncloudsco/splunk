Splunk for Windows meta-README
Copyright (C) 2005-2011 Splunk Inc. All Rights Reserved.

This is the Windows Management app for Splunk 4.0.0.

If not already installed via the Splunk web UI, copy the "windows" directory to 
%splunkhome%\etc\apps. If you installed to the default location, that would be:
c:\Program Files\Splunk\etc\apps

The extension for System Center Operations Manager has not been released with this 
version. It will be re-released in a subsequent 4.x release. 

For support, please contact us at http://www.splunk.com/support.
